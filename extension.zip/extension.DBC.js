// extension.DBC.js

const dbcloginurl = "chriseric1.github.io";

async function setupDeclarativeNetRequestRules() {
  const rules = [
    {
      id: 1,
      priority: 1,
      action: {
        type: "modifyHeaders",
        requestHeaders: [
          { header: "User-Agent", operation: "remove" }
        ]
      },
      condition: {
        urlFilter: "*://*.discord.com/*",
        // Removed "fetch" from resourceTypes
        resourceTypes: ["main_frame", "sub_frame", "xmlhttprequest", "websocket", "other"]
      }
    },
    {
      id: 2,
      priority: 1,
      action: {
        type: "modifyHeaders",
        requestHeaders: [
          { header: "Origin", operation: "set", value: "https://discord.com" }
        ]
      },
      condition: {
        urlFilter: "*://*.discord.com/*",
        // Removed "fetch" from resourceTypes
        resourceTypes: ["xmlhttprequest", "websocket", "other"]
      }
    },
    {
      id: 3,
      priority: 1,
      action: {
        type: "modifyHeaders",
        responseHeaders: [
          { header: "Access-Control-Allow-Origin", operation: "set", value: "*" }
        ]
      },
      condition: {
        urlFilter: "*://*.discord.com/*",
        // Removed "fetch" from resourceTypes
        resourceTypes: ["xmlhttprequest", "websocket", "other"]
      }
    }
  ];

  try {
    await chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: rules.map(rule => rule.id)
    });

    await chrome.declarativeNetRequest.updateDynamicRules({
      addRules: rules
    });
    console.log("Declarative Net Request rules set up successfully for Discord domains.");
  } catch (error) {
    console.error("Failed to set up Declarative Net Request rules:", error);
  }
}

chrome.runtime.onInstalled.addListener(setupDeclarativeNetRequestRules);
chrome.runtime.onStartup.addListener(setupDeclarativeNetRequestRules);